const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
const scoreDisplay = document.getElementById('scoreDisplay');

// Game constants
canvas.width = 800;
canvas.height = 450; // A bit wider than tall for a basketball court feel

const GRAVITY = 0.5;
const FLOOR_Y = canvas.height - 30; // Ground level

// --- Game State ---
let player1 = {
    x: 100,
    y: FLOOR_Y - 50, // Start on the ground
    width: 40,
    height: 60,
    color: 'blue',
    velocityY: 0,
    speed: 5,
    jumpForce: 12,
    onGround: true,
    hasBall: true, // Player 1 starts with the ball
    score: 0,
    facingRight: true
};

let player2 = { // AI or second player (very basic placeholder)
    x: canvas.width - 150,
    y: FLOOR_Y - 50,
    width: 40,
    height: 60,
    color: 'red',
    velocityY: 0,
    speed: 3, // Slower for simple AI
    onGround: true,
    hasBall: false,
    score: 0,
    facingRight: false
};

let ball = {
    x: player1.x + player1.width / 2,
    y: player1.y - 20,
    radius: 10,
    color: 'orange',
    velocityX: 0,
    velocityY: 0,
    heldBy: player1, // Reference to the player holding the ball
    isShot: false
};

const hoop = {
    x: canvas.width - 90, // Right side hoop
    y: canvas.height / 2 - 50,
    rimY: canvas.height / 2 - 50 + 10, // Y-coordinate of the rim top
    rimXStart: canvas.width - 90,
    rimXEnd: canvas.width - 90 + 50,
    width: 50,
    height: 10, // Rim thickness
    backboardWidth: 5,
    backboardHeight: 80,
    color: 'grey',
    netColor: 'white'
};

const hoop2 = { // Left side hoop
    x: 40,
    y: canvas.height / 2 - 50,
    rimY: canvas.height / 2 - 50 + 10,
    rimXStart: 40,
    rimXEnd: 40 + 50,
    width: 50,
    height: 10,
    backboardWidth: 5,
    backboardHeight: 80,
    color: 'grey',
    netColor: 'white'
};


// --- Input Handling ---
let keys = {
    ArrowLeft: false,
    ArrowRight: false,
    ArrowUp: false,
    Space: false
};

window.addEventListener('keydown', (e) => {
    if (keys.hasOwnProperty(e.key)) {
        keys[e.key] = true;
    }
});

window.addEventListener('keyup', (e) => {
    if (keys.hasOwnProperty(e.key)) {
        keys[e.key] = false;
    }
});

// --- Game Logic Functions ---
function updatePlayer(player) {
    // Horizontal Movement
    if (player === player1) { // Only control player 1 for now
        if (keys.ArrowLeft) {
            player.x -= player.speed;
            player.facingRight = false;
        }
        if (keys.ArrowRight) {
            player.x += player.speed;
            player.facingRight = true;
        }

        // Jumping
        if (keys.ArrowUp && player.onGround) {
            player.velocityY = -player.jumpForce;
            player.onGround = false;
        }
    }

    // Apply gravity
    player.velocityY += GRAVITY;
    player.y += player.velocityY;

    // Floor collision
    if (player.y + player.height >= FLOOR_Y) {
        player.y = FLOOR_Y - player.height;
        player.velocityY = 0;
        player.onGround = true;
    }

    // Keep player within canvas bounds (simple)
    if (player.x < 0) player.x = 0;
    if (player.x + player.width > canvas.width) player.x = canvas.width - player.width;
}

function updateBall() {
    if (ball.heldBy) {
        // Ball follows the player holding it
        ball.x = ball.heldBy.x + (ball.heldBy.facingRight ? ball.heldBy.width : -ball.radius*2);
        ball.y = ball.heldBy.y + ball.heldBy.height / 3;
        ball.velocityX = 0;
        ball.velocityY = 0;
        ball.isShot = false;
    } else if (ball.isShot) {
        // Ball is in motion (shot or passed)
        ball.velocityY += GRAVITY / 2; // Less gravity for a floatier shot feel
        ball.x += ball.velocityX;
        ball.y += ball.velocityY;

        // Basic wall bounce (sides only for now)
        if (ball.x - ball.radius < 0 || ball.x + ball.radius > canvas.width) {
            ball.velocityX *= -0.7; // Dampen horizontal bounce
            ball.x = (ball.x - ball.radius < 0) ? ball.radius : canvas.width - ball.radius;
        }

        // Floor bounce
        if (ball.y + ball.radius > FLOOR_Y) {
            ball.y = FLOOR_Y - ball.radius;
            ball.velocityY *= -0.6; // Dampen vertical bounce
            if (Math.abs(ball.velocityY) < 1 && Math.abs(ball.velocityX) < 0.5) { // Settle down
                ball.isShot = false; // Ball stops being "in shot"
                ball.velocityX = 0;
                ball.velocityY = 0;
            }
        }
        // Check for score
        checkScore();
        // Check for pickup
        checkBallPickup();
    }
}

function shootBall(player) {
    if (player.hasBall) {
        ball.heldBy = null;
        ball.isShot = true;
        player.hasBall = false;

        // Simple shot logic
        const shootPower = 10;
        // const angleFactor = player.facingRight ? 1 : -1; // Shoots towards facing direction
        const targetHoop = player.facingRight ? hoop : hoop2;

        // Calculate angle towards hoop (very simplified)
        let dx = (targetHoop.x + targetHoop.width/2) - (player.x + player.width/2);
        let dy = (targetHoop.y + targetHoop.height/2) - (player.y + player.height/2);
        let angle = Math.atan2(dy, dx);

        ball.velocityX = Math.cos(angle) * shootPower;
        ball.velocityY = Math.sin(angle) * shootPower - 3; // Add a bit of upward thrust to compensate for gravity

        // console.log(`Shot from ${player.color}: vx=${ball.velocityX.toFixed(2)}, vy=${ball.velocityY.toFixed(2)}`);
    }
}

function checkScore() {
    // Check for player 1 scoring on hoop (right hoop)
    if (ball.x > hoop.rimXStart && ball.x < hoop.rimXEnd &&
        ball.y > hoop.rimY - ball.radius && ball.y < hoop.rimY + ball.radius + 5 && // a bit of leeway
        ball.velocityY > 0) { // Ball must be falling
        // console.log("Player 1 scores!");
        player1.score += 2;
        resetBall(player2); // Player 2 gets the ball
    }

    // Check for player 2 scoring on hoop2 (left hoop)
    if (ball.x > hoop2.rimXStart && ball.x < hoop2.rimXEnd &&
        ball.y > hoop2.rimY - ball.radius && ball.y < hoop2.rimY + ball.radius + 5 &&
        ball.velocityY > 0) {
        // console.log("Player 2 scores!");
        player2.score += 2;
        resetBall(player1); // Player 1 gets the ball
    }
    updateScoreDisplay();
}

function resetBall(playerToGiveBall) {
    ball.isShot = false;
    ball.heldBy = playerToGiveBall;
    playerToGiveBall.hasBall = true;
    if (playerToGiveBall === player1) {
        player2.hasBall = false; // Ensure other player doesn't have ball
        ball.x = player1.x + (player1.facingRight ? player1.width : -ball.radius*2);
        ball.y = player1.y + player1.height / 3;
    } else {
        player1.hasBall = false; // Ensure other player doesn't have ball
        ball.x = player2.x + (player2.facingRight ? player2.width : -ball.radius*2);
        ball.y = player2.y + player2.height / 3;
    }
    ball.velocityX = 0;
    ball.velocityY = 0;
}

function checkBallPickup() {
    if (!ball.heldBy && !ball.isShot && ball.y + ball.radius >= FLOOR_Y -5) { // If ball is on/near the ground and not being held/shot
        // Check pickup by player 1
        if (isColliding(player1, {x: ball.x - ball.radius, y: ball.y - ball.radius, width: ball.radius*2, height: ball.radius*2})) {
            ball.heldBy = player1;
            player1.hasBall = true;
            player2.hasBall = false;
        }
        // Check pickup by player 2
        else if (isColliding(player2, {x: ball.x - ball.radius, y: ball.y - ball.radius, width: ball.radius*2, height: ball.radius*2})) {
            ball.heldBy = player2;
            player2.hasBall = true;
            player1.hasBall = false;
        }
    }
}

function isColliding(rect1, rect2) {
    return rect1.x < rect2.x + rect2.width &&
           rect1.x + rect1.width > rect2.x &&
           rect1.y < rect2.y + rect2.height &&
           rect1.y + rect1.height > rect2.y;
}


function updateScoreDisplay() {
    scoreDisplay.textContent = `Player 1: ${player1.score} | Player 2: ${player2.score}`;
}

// --- AI Logic (VERY simple) ---
function updateAI(aiPlayer) {
    const opponentHoop = hoop; // Player 2 (AI) scores on the right hoop

    if (aiPlayer.hasBall) {
        // Move towards opponent's hoop
        if (aiPlayer.x < opponentHoop.x - aiPlayer.width - 50) { // If too far left of target hoop
            aiPlayer.x += aiPlayer.speed;
            aiPlayer.facingRight = true;
        } else if (aiPlayer.x > opponentHoop.x - aiPlayer.width) { // If too far right (past it)
            aiPlayer.x -= aiPlayer.speed;
            aiPlayer.facingRight = false;
        } else { // In a reasonable range
             aiPlayer.facingRight = true; // Face the hoop
        }

        // Simple shooting logic (if near hoop and facing it)
        const distanceToHoop = Math.abs(aiPlayer.x - (opponentHoop.x + opponentHoop.width/2));
        if (distanceToHoop < 200 && aiPlayer.facingRight) {
            if (Math.random() < 0.015) { // Random chance to shoot
                 shootBall(aiPlayer);
            }
        }

    } else if (!ball.heldBy && !ball.isShot) { // If ball is loose and on the ground
        if (ball.x < aiPlayer.x + aiPlayer.width / 2) {
            aiPlayer.x -= aiPlayer.speed;
            aiPlayer.facingRight = false;
        } else {
            aiPlayer.x += aiPlayer.speed;
            aiPlayer.facingRight = true;
        }
    } else if (ball.heldBy === player1) { // Defend: try to stay between player1 and AI's hoop (hoop2)
        const defendedHoop = hoop2; // AI defends left hoop
        if (player1.x > aiPlayer.x + aiPlayer.width / 2 && player1.x < defendedHoop.x - 20) {
            // If P1 is to the right of AI but before AI's hoop, AI moves right
            aiPlayer.x += aiPlayer.speed / 1.5;
            aiPlayer.facingRight = true;
        } else if (player1.x < aiPlayer.x && player1.x > 20) {
            // If P1 is to the left of AI, AI moves left
             aiPlayer.x -= aiPlayer.speed / 1.5;
             aiPlayer.facingRight = false;
        }
    }

    // AI random jump (less effective, just for show)
    if (aiPlayer.onGround && Math.random() < 0.01) {
        aiPlayer.velocityY = -aiPlayer.jumpForce / 1.5; // Weaker jump
        aiPlayer.onGround = false;
    }

    // Apply gravity & floor (copied from updatePlayer, could be refactored)
    aiPlayer.velocityY += GRAVITY;
    aiPlayer.y += aiPlayer.velocityY;
    if (aiPlayer.y + aiPlayer.height >= FLOOR_Y) {
        aiPlayer.y = FLOOR_Y - aiPlayer.height;
        aiPlayer.velocityY = 0;
        aiPlayer.onGround = true;
    }
    if (aiPlayer.x < 0) aiPlayer.x = 0;
    if (aiPlayer.x + aiPlayer.width > canvas.width) aiPlayer.x = canvas.width - aiPlayer.width;
}

// --- Drawing Functions ---
function drawRect(x, y, width, height, color) {
    ctx.fillStyle = color;
    ctx.fillRect(x, y, width, height);
}

function drawCircle(x, y, radius, color) {
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.arc(x, y, radius, 0, Math.PI * 2);
    ctx.fill();
    ctx.closePath();
}

function drawHoop(hoopObj) {
    // Backboard
    const backboardX = hoopObj.x < canvas.width/2 ? hoopObj.x + hoopObj.width : hoopObj.x - hoopObj.backboardWidth;
    drawRect(backboardX, hoopObj.y - hoopObj.backboardHeight/2 + hoopObj.height/2, hoopObj.backboardWidth, hoopObj.backboardHeight, hoopObj.color);
    // Rim
    drawRect(hoopObj.x, hoopObj.y, hoopObj.width, hoopObj.height, hoopObj.color);
    // Net (simple lines)
    ctx.strokeStyle = hoopObj.netColor;
    ctx.lineWidth = 2;
    for (let i = 0; i <= 4; i++) {
        ctx.beginPath();
        ctx.moveTo(hoopObj.x + (hoopObj.width / 4) * i, hoopObj.y + hoopObj.height);
        ctx.lineTo(hoopObj.x + hoopObj.width / 2, hoopObj.y + hoopObj.height + 40); // Net bottom point
        ctx.stroke();
    }
}

function drawCourt() {
    // Floor
    drawRect(0, FLOOR_Y, canvas.width, canvas.height - FLOOR_Y, '#654321'); // Brown
    // Center line
    // drawRect(canvas.width/2 - 2, FLOOR_Y - 150, 4, 150, 'white'); // a bit of 3 point line
    // Half court circle
    ctx.beginPath();
    ctx.arc(canvas.width/2, FLOOR_Y, 60, Math.PI, 2*Math.PI, false); // Semicircle on the floor
    ctx.strokeStyle = 'white';
    ctx.lineWidth = 4;
    ctx.stroke();
    // Center line from circle to top
    ctx.beginPath();
    ctx.moveTo(canvas.width/2, FLOOR_Y - 60);
    ctx.lineTo(canvas.width/2, 0); // extend to top of screen or a certain height
    ctx.stroke();
    ctx.closePath();


    // Simple 3-point lines (arcs)
    const threePointRadius = 200;
    const hoop1CenterY = hoop.y + hoop.height / 2;
    const hoop2CenterY = hoop2.y + hoop2.height / 2;

    // Hoop 1 (right) 3-point line
    ctx.beginPath();
    ctx.arc(hoop.x + hoop.width / 2, hoop1CenterY, threePointRadius, Math.PI / 2 + 0.4, Math.PI * 3 / 2 - 0.4, false); // Adjusted angles for typical 3pt line
    ctx.strokeStyle = 'white';
    ctx.lineWidth = 4;
    ctx.stroke();
    ctx.closePath();

    // Hoop 2 (left) 3-point line
    ctx.beginPath();
    ctx.arc(hoop2.x + hoop2.width / 2, hoop2CenterY, threePointRadius, Math.PI / 2 - 0.4, -Math.PI/2 + 0.4, true); // Adjusted angles
    ctx.strokeStyle = 'white';
    ctx.lineWidth = 4;
    ctx.stroke();
    ctx.closePath();

}

function draw() {
    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw background (sky color is canvas default for now)

    drawCourt();

    // Draw Hoops
    drawHoop(hoop);
    drawHoop(hoop2);

    // Draw Player 1
    drawRect(player1.x, player1.y, player1.width, player1.height, player1.color);

    // Draw Player 2 (AI)
    drawRect(player2.x, player2.y, player2.width, player2.height, player2.color);

    // Draw Ball
    drawCircle(ball.x, ball.y, ball.radius, ball.color);

}

// --- Game Loop ---
function gameLoop() {
    // Update game state
    updatePlayer(player1);
    updateAI(player2); // Update AI player
    updateBall();

    if (keys.Space && player1.hasBall) { // Player 1 shoots
        shootBall(player1);
        keys.Space = false; // Prevent holding space to auto-shoot
    }

    // Draw everything
    draw();

    requestAnimationFrame(gameLoop); // Keeps the loop going
}

// --- Start Game ---
updateScoreDisplay();
gameLoop();